---
name: '🗣 Have a question / start a discussion'
about: You want to ask or discuss something
label: 'Question/Discussion'
---

## You want to:  
<!-- Ask question / Discuss something -->

## Details:
<!-- Place for your question/discussion -->