---
name: '🔧 Feature request'
about: New functionality for Async Storage
label: 'Enhancement'
---

## Motivation

<!-- Describe the context, the use-case and the advantages of the feature request. -->

## Description

<!-- Describe the functional changes that would have to be made -->

## New feature implementation

<!-- Optionally, describe the technical changes to be made -->